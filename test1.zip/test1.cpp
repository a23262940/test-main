#include<iostream>
using namespace std;
int main(){
    int in,get,right=0,left=100;
    while(true){
        cin >> in;
        if(in>=0 && in<=100){
            cout << "Get your Answer\n";
            break;
        }else{
            cout << "Out of Range\n";
        }
    }
    while(true){
        cin >> get;
        if(get>=0 && get<=100){
            if(in==get){
                cout << "BINGO\n";
                break;
            }else if(in>get && right<=get){
                right = get + 1;
                cout << "[" << right << ", " << left << "]\n";
            }else if(in<get && left >= get){
                left = get - 1;
                cout << "[" << right << ", " << left << "]\n";
            }else{
                cout << "Out of Range\n";
            }
        }else{
            cout << "Out of Range\n";
        }
    }
}